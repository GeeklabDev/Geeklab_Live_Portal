<?php return array (
  'add-student' => 'App\\Http\\Livewire\\AddStudent',
  'chat' => 'App\\Http\\Livewire\\Chat',
  'check-homework' => 'App\\Http\\Livewire\\CheckHomework',
  'employment' => 'App\\Http\\Livewire\\Employment',
  'group' => 'App\\Http\\Livewire\\Group',
  'homwork' => 'App\\Http\\Livewire\\Homwork',
  'posts' => 'App\\Http\\Livewire\\Posts',
);